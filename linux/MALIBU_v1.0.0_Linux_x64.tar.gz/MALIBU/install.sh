#!/bin/bash

PLUGIN_NAME="MALIBU"
VST3_DIR="$HOME/.vst3"

echo "Installing $PLUGIN_NAME v1.0.0..."

# Create VST3 directory if it doesn't exist
mkdir -p "$VST3_DIR"

# Copy plugin
cp -R "$PLUGIN_NAME.vst3" "$VST3_DIR/"

# Set permissions
chmod -R 755 "$VST3_DIR/$PLUGIN_NAME.vst3"

echo "✅ $PLUGIN_NAME installed successfully!"
echo "Plugin location: $VST3_DIR/$PLUGIN_NAME.vst3"
echo ""
echo "Next steps:"
echo "1. Restart your DAW"
echo "2. Rescan for new plugins"
echo "3. Look for $PLUGIN_NAME under 'Solmar Labs'"
echo ""
echo "For support, visit: https://solmarlabs.com"
