MALIBU v1.0.0 - Linux Installation Package
=============================================

WHAT'S INCLUDED:
- MALIBU.vst3 - VST3 plugin
- install.sh - Automatic installation script
- uninstall.sh - Uninstallation script

INSTALLATION:
1. Extract this package to any directory
2. Run: ./install.sh
3. Restart your DAW and rescan plugins

MANUAL INSTALLATION:
1. Copy MALIBU.vst3 to ~/.vst3/
2. Set permissions: chmod -R 755 ~/.vst3/MALIBU.vst3

SYSTEM REQUIREMENTS:
- Linux x86_64 (64-bit)
- VST3-compatible DAW
- 4 GB RAM minimum

SUPPORT: support@solmarlabs.com
WEBSITE: https://solmarlabs.com

Copyright © 2025 Solmar Labs. All rights reserved.
