#!/bin/bash

PLUGIN_NAME="MALIBU"
VST3_DIR="$HOME/.vst3"

echo "Uninstalling $PLUGIN_NAME..."

if [ -d "$VST3_DIR/$PLUGIN_NAME.vst3" ]; then
    rm -rf "$VST3_DIR/$PLUGIN_NAME.vst3"
    echo "✅ $PLUGIN_NAME uninstalled successfully!"
else
    echo "⚠️  $PLUGIN_NAME not found in $VST3_DIR"
fi
